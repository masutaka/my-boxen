require 'spec_helper'

describe 'limechat' do
  it do
    should contain_package('LimeChat').with({
      :provider => 'compressed_app',
      :flavor   => 'tbz',
      :source   => 'https://downloads.sourceforge.net/project/limechat/limechat/LimeChat_2.38.tbz?use_mirror=master'
    })
  end
end
