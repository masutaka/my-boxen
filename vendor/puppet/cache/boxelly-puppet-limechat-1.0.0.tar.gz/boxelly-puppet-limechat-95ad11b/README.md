# LimeChat Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxelly/puppet-limechat.png?branch=master)](https://travis-ci.org/boxelly/puppet-limechat)

## Usage

```puppet
    include limechat
```

## Required Puppet Modules

* `boxen`
* `stdlib`

